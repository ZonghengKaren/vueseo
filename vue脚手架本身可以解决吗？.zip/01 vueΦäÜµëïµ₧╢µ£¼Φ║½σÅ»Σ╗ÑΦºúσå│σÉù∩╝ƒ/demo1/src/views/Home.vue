<template>
  <div class="home">
    <img alt="Vue logo" src="../assets/logo.png" />
    {{ a }}
  </div>
</template>

<script>
import axios from 'axios'
export default {
  name: "Home",
  data (){
  	return {
  		a:''
  	}
  },
  created(){
  	axios({
  		url:'http://localhost:3000/list'
  	}).then(res=>{
  		this.a = res.data.a;
  	})
  }
};
</script>

<template>
	<div>
		这是轮播图
	</div>
</template>
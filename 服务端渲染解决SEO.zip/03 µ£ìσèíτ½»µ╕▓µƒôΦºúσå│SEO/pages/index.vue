<template>
  <div>
    <ul>
      <li v-for='(item,index) in list' :key='item.id'>
        {{item.imageUrl}}
      </li>
    </ul>
  </div>
</template>

<script>
import axios from 'axios'
export default {
  name: 'IndexPage',
  data () {
    return {
      list:[]
    }
  },
  head() {
    // 优化seo：动态设置title，keywords 和 description
    return {
      title: this.list[0].imageUrl,
      meta: [
        {
          name: "keywords",
          content:
            "淘宝，西瓜视频，抖音，今日头条，懂球帝，微信，微博",
        },
        // hid是一个唯一标识
        {
            hid: 'description', name: 'names', content: '应用大全'
        },
      ],
    };
  },
  async asyncData({ params }) {
    const { data } = await axios.get('http://testapi.xuexiluxian.cn/api/slider/getSliders')
    return { list: data.data.list }
  }
}
</script>

<template>
	<div>
		新闻页
	</div>
</template>

<script>
export default {
  name: 'News',
  head() {
    // 优化seo：动态设置title，keywords 和 description
    return {
      title: '新闻',
      meta: [
        {
          name: "keywords",
          content:
            "淘宝，西瓜视频，抖音，今日头条，懂球帝，微信，微博",
        },
        // hid是一个唯一标识
        {
            hid: 'description', name: 'names', content: '应用大全'
        },
      ],
    };
  },
}
</script>
<template>
  <h2>About Page</h2>
</template>

<script>
  export default {
    metaInfo: {
      title: '关于我们', // set a title
      meta: [{                 // set meta
        name: 'keyWords',
        content: 'My Example App'
      }]
    }
  }
</script> 
<template>
  <h2>
    首页
    {{ a }}
  </h2>
</template>

<script>
import axios from 'axios'
export default {
  metaInfo: {
    title: this.a, // set a title
    meta: [{                 // set meta
      name: '关键字,web前端',
      content: '描述'
    }]
  },
  data () {
    return {
      a:''
    }
  },
  created(){
    axios({
      url:'http://localhost:3000/list'
    }).then(res=>{
      this.a = res.data.a;
    })
  }
}
</script> 

<template>
  <h2>Contact Page</h2>
</template>

<script>
export default {
  metaInfo: {
    title: 'contact',
    meta: [{
      name: 'keyWords',
      content: 'My Example App'
    }]
  }
}
</script> 